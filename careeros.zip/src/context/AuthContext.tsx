import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isOnboarded: boolean;
  login: (email: string, password?: string) => Promise<boolean>;
  register: (name: string, email: string, password?: string) => Promise<boolean>;
  loginWithGoogle: () => Promise<boolean>;
  logout: () => void;
  updateUser: (updated: Partial<User>) => void;
  completeOnboarding: () => void;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY_USER = 'careeros_user';
const STORAGE_KEY_ONBOARDED = 'careeros_onboarded';

const defaultUser: User = {
  id: 'usr_eshan_001',
  name: 'Eshan Saxena',
  email: 'eshanbsaxena@gmail.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&auto=format&fit=crop&q=80',
  headline: 'Senior Full-Stack & AI Systems Engineer',
  createdAt: '2026-08-01T00:00:00.000Z',
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return defaultUser;
      }
    }
    return defaultUser;
  });

  const [isOnboarded, setIsOnboarded] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ONBOARDED);
    return saved ? JSON.parse(saved) : true;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY_USER);
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ONBOARDED, JSON.stringify(isOnboarded));
  }, [isOnboarded]);

  const login = async (email: string, password?: string) => {
    const u: User = {
      id: 'usr_' + Math.random().toString(36).substring(2, 9),
      name: email.split('@')[0] ? email.split('@')[0].replace('.', ' ').replace(/^./, (str) => str.toUpperCase()) : 'Candidate',
      email: email || 'eshanbsaxena@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&auto=format&fit=crop&q=80',
      headline: 'Software Engineer',
      createdAt: new Date().toISOString(),
    };
    setUser(u);
    return true;
  };

  const register = async (name: string, email: string, password?: string) => {
    const u: User = {
      id: 'usr_' + Math.random().toString(36).substring(2, 9),
      name: name || 'New Candidate',
      email: email,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&auto=format&fit=crop&q=80',
      headline: 'Software Engineer',
      createdAt: new Date().toISOString(),
    };
    setUser(u);
    setIsOnboarded(false); // trigger onboarding for new users
    return true;
  };

  const loginWithGoogle = async () => {
    const u: User = {
      id: 'usr_google_001',
      name: 'Eshan Saxena',
      email: 'eshanbsaxena@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&auto=format&fit=crop&q=80',
      headline: 'Senior Full-Stack & AI Systems Engineer',
      createdAt: new Date().toISOString(),
    };
    setUser(u);
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  const updateUser = (updated: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...updated });
    }
  };

  const completeOnboarding = () => {
    setIsOnboarded(true);
  };

  const resetPassword = async (email: string) => {
    return {
      success: true,
      message: `Password reset instructions have been securely sent to ${email}`,
    };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isOnboarded,
        login,
        register,
        loginWithGoogle,
        logout,
        updateUser,
        completeOnboarding,
        resetPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
