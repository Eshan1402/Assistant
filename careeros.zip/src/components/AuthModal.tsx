import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Bot,
  Mail,
  Lock,
  User,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { login, register, loginWithGoogle, resetPassword } = useAuth();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [name, setName] = useState('Eshan Saxena');
  const [email, setEmail] = useState('eshanbsaxena@gmail.com');
  const [password, setPassword] = useState('••••••••••••');
  const [message, setMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    try {
      if (mode === 'login') {
        await login(email, password);
      } else if (mode === 'register') {
        await register(name, email, password);
      } else if (mode === 'forgot') {
        const res = await resetPassword(email);
        setMessage(res.message);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setIsLoading(true);
    try {
      await loginWithGoogle();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080414] backdrop-blur-2xl">
      {/* Ambient glowing radial effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-purple-600/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-[#130b2e]/95 border border-purple-600/40 shadow-2xl shadow-purple-950 p-6 sm:p-8 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-3xl bg-gradient-to-tr from-purple-700 via-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-xl shadow-purple-900/60 border border-purple-400/30">
            <Bot className="w-7 h-7 animate-pulse-glow" />
          </div>

          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              CareerOS<span className="text-purple-400">.</span>
            </h1>
            <p className="text-xs text-purple-300/80 mt-1">
              Autonomous AI Career Agent & Job Intelligence
            </p>
          </div>
        </div>

        {/* Mode Toggle Tabs */}
        {mode !== 'forgot' && (
          <div className="flex p-1 rounded-2xl bg-purple-950/60 border border-purple-800/40 text-xs">
            <button
              type="button"
              onClick={() => setMode('login')}
              className={`flex-1 py-2 rounded-xl font-bold transition-all ${
                mode === 'login'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setMode('register')}
              className={`flex-1 py-2 rounded-xl font-bold transition-all ${
                mode === 'register'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              Create Account
            </button>
          </div>
        )}

        {/* Status Message */}
        {message && (
          <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-500/40 text-xs text-purple-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{message}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {mode === 'register' && (
            <div>
              <label className="block text-purple-300 font-medium mb-1">Your Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Eshan Saxena"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-purple-950/70 border border-purple-700/40 text-white placeholder:text-purple-400/50 focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-purple-300 font-medium mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-purple-950/70 border border-purple-700/40 text-white placeholder:text-purple-400/50 focus:outline-none focus:border-purple-400"
              />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-purple-300 font-medium">Password</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-purple-400 hover:text-purple-300 text-[11px]"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-purple-950/70 border border-purple-700/40 text-white placeholder:text-purple-400/50 focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold shadow-lg shadow-purple-900/50 transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-50"
          >
            <span>
              {mode === 'login'
                ? 'Sign In to CareerOS'
                : mode === 'register'
                ? 'Create Autonomous Agent Account'
                : 'Send Password Reset'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Google OAuth Option */}
        <div className="space-y-3 pt-2">
          <div className="relative flex items-center justify-center">
            <div className="w-full border-t border-purple-900/40" />
            <span className="absolute px-3 bg-[#130b2e] text-[11px] text-purple-400/70 uppercase">
              Or continue with
            </span>
          </div>

          <button
            type="button"
            onClick={handleGoogleAuth}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2.5 py-2.5 rounded-full bg-purple-950/80 hover:bg-purple-900/80 border border-purple-700/40 text-white text-xs font-semibold transition-all hover:scale-[1.01]"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>
        </div>

        {mode === 'forgot' && (
          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => setMode('login')}
              className="text-xs text-purple-400 hover:text-white underline"
            >
              Back to Sign In
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
